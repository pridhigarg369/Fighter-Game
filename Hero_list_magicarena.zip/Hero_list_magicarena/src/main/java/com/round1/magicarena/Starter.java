package com.round1.magicarena;

import java.util.ArrayList;
import java.util.List;
import com.round1.magicarena.entities.Fighter;
import com.round1.magicarena.processImpl.StarterProcessImpl;

/**
 *
 * ${preparing character data on game start up and start the process}
 */
public class Starter 
{
	//public static final List<Fighter> fighters=new ArrayList<>();
    public static void main( String[] args )
    {
//    	Fighter kai = new Fighter("Kai",200,20,35);
//    	Fighter pina = new Fighter("Pina",250,40,25);
//    	Fighter doroku = new Fighter("Doroku",220,30,30);
//    	Fighter chin = new Fighter("chin",230,25,30);

    	//List of available fighters for fight
    	
//    	fighters.add(doroku);
//    	fighters.add(pina);
//    	fighters.add(kai);
//    	fighters.add(chin);    	
    	
    	
    	StarterProcessImpl process = new StarterProcessImpl();       
        process.processor();
    }
}
