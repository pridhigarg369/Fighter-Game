//package com.round1.magicarena.utility;
//
//import java.util.Scanner;
//
//import com.round1.magicarena.Starter;
//
//public class IoHelper {
//	private static Scanner sc = new Scanner(System.in);
//
//// 2 Attempts to get Fighter id 	
//	public static int getfighterID() {
//
//		int id = 0;
//
//		try {
//			int tries =1;
//			id = sc.nextInt();
//			while(true && tries!=3) {
//			
//			if (id == 0) {
//				System.out.print("Sucessful Exit.");
//				abortGame();
//			} else if (id <= Starter.fighters.size()) {
//				return id;
//			} else {
//				System.out.println("Invalid Fighter Id: Please enter valid id again");
//				tries++;
//				id=sc.nextInt();
//			}
//			}
//			System.out.println("Game Aborted after 3 Failed Selection Attempts, Please Restart");
//			abortGame();
//		} catch (Exception e) {
//			//System.out.println("Invalid Fighter Id: Game Aborted after 3 Attempts");
//			e.printStackTrace();
//			System.exit(0);
//		}
//		return 0;
//	}
//	
//	public static int abortGame() {
//		System.exit(0);
//		return 0;
//	}
//
//}
