package com.round1.magicarena.processImpl;

import java.util.Scanner;

import com.round1.magicarena.Starter;
import com.round1.magicarena.entities.Fighter;
import com.round1.magicarena.process.StarterProcess;
import com.round1.magicarena.utility.DiceRoller;
//import com.round1.magicarena.utility.IoHelper;

public class StarterProcessImpl implements StarterProcess {

	@Override
	public void processor() {
		Fighter player1 =new Fighter();
		Fighter player2=new Fighter();
		int heroId = 1;
		System.out.println("\n\n***************\t  Heyy There Players! \t*****************\n");
		
		try {
			Thread.sleep(1000);
//			System.out.println("Available Fighters : ");
//			for (Fighter e : Starter.fighters) {
//				System.out.println(heroId + ". " + e.getName() + " -> Health: " + e.getHealth() + " Strength: "+ e.getStrength() + " Attack Power: " + e.getAttack());
//				heroId++;
//			}
//			System.out.println("0 -> Exit Game");
//			//Player 1
//			
//			// User Inputs for chosen fighters
//			System.out.print("\n Player: Choose your Fighter id ->");
//			int player1Id = IoHelper.getfighterID();
//			player1 = Starter.fighters.get(player1Id - 1);
//			Starter.fighters.remove(player1Id - 1);
//
//			//Player 2
//			heroId = 1;
//			for (Fighter e : Starter.fighters) {
//				System.out.println("\n"+heroId + ". " + e.getName() + " -> Health: " + e.getHealth() + " Strength: "+ e.getStrength() + " Attack Power: " + e.getAttack());
//				heroId++;
//			}
//			System.out.println("0 -> Exit Game");
//			System.out.print("\n Opponent Player : Choose your Fighter id ->");
//			int player2Id = IoHelper.getfighterID();
//			player2 = Starter.fighters.get(player2Id - 1);

			player1.setAttack(DiceRoller.attack());
			player1.setHealth(DiceRoller.health());
			player1.setStrength(DiceRoller.strength());
			player1.setName("Player1 ");
			player2.setAttack(DiceRoller.attack());
			player2.setHealth(DiceRoller.health());
			player2.setStrength(DiceRoller.strength());
			player2.setName("Player2 ");
			
			BattlefieldImpl battle = new BattlefieldImpl();
			String winner = battle.battleBegin(player1, player2);
			
			System.out.println("\n*****************\t Winner\t: "+winner);
			
		} catch (Exception e) {
			System.out.println("Process Aborted\n Please restart the game and Enter a valid fighter ID");
			e.printStackTrace();
		}

	}
}
