package com.round1.magicarena.utility;

public class DiceRoller {
	
	public static int diceRoll() {
		
		int rollingNo= (int)(Math.random()*6)+1; 
		return rollingNo;
		
	}
	
public static int health() {
		
		int health= (int)(Math.random()*200)+1; 
		return health;
		
	}
public static int strength() {
	
	int strength= (int)(Math.random()*10)+1; 
	return strength;
	
}
public static int attack() {
	
	int attack= (int)(Math.random()*30)+1; 
	return attack;
	
}

}
