package com.round1.magicarena.process;

import com.round1.magicarena.entities.Fighter;
public interface Battlefield {
	
	public String battleBegin(Fighter player1, Fighter player2);

}
