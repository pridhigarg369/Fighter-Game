package com.round1.magicarena.processImpl;

import com.round1.magicarena.process.Battlefield;
import com.round1.magicarena.utility.DiceRoller;
import com.round1.magicarena.entities.Fighter;

public class BattlefieldImpl implements Battlefield {

	@Override
	public String battleBegin(Fighter player1, Fighter player2) {
		

		Fighter attacker1;
		Fighter attacker2;
		try {

			if (player1.getHealth() >= player2.getHealth()) {
				attacker1 = player2;
				attacker2 = player1;
			} else {
				attacker1 = player1;
				attacker2 = player2;
			}
			System.out.println("\n**********\tPlayer 1 : " + attacker1.getName() + " VS Player 2 : "+ attacker2.getName() + "      **********");

			// Attack Begin
			System.out.println("\n\t\t\t"+attacker1.getName()+" Starts The Battle\n");
			System.out.println("\t\t\t   Battle Begins");
			int round=1;
			while (attacker2.getHealth() > 0 && attacker1.getHealth() > 0) {
				Thread.sleep(2000);
				System.out.println("Round - "+round);
				int attackDiceRoll = DiceRoller.diceRoll();
				int defenceDiceRoll = DiceRoller.diceRoll();
				int attack = 0;
				// Turn 1
				System.out.println("Attacker1 Attacks");
				if (attacker1.getHealth() > 0) {
					attack = attacker1.getAttack() * attackDiceRoll - attacker2.getStrength() * defenceDiceRoll;
					System.out.println("\t AttackDiceRoll "+ attackDiceRoll+ "\tDefenceDiceRoll "+defenceDiceRoll);
					System.out.print("\t Attack: "+attacker1.getAttack() * attackDiceRoll+ "\tDefence: "+  attacker2.getStrength() * defenceDiceRoll);
					if (attack > 0) {
						System.out.println("\tDamage: " + attack);
						attacker2.setHealth(attacker2.getHealth() - attack);
					} else {
						System.out.println("\nAttack defended by "+ attacker1.getName());
					}
					System.out.println("\n\tStats :\n \tAttacker1: " + attacker1.toString() + "\n \tAttacker2: " + attacker2.toString());
					Thread.sleep(1000);
				} else {
					System.out.println("Attacker1 is Dead");
					return attacker1.getName();
				}
				// Turn 2
				System.out.println("\nAttacker2 Attacks");
				
				if (attacker2.getHealth() > 0) {
					attackDiceRoll = DiceRoller.diceRoll();
					defenceDiceRoll = DiceRoller.diceRoll();

					attack = attacker2.getAttack() * attackDiceRoll - attacker1.getStrength() * defenceDiceRoll;
					System.out.println("\t AttackDiceRoll "+ attackDiceRoll+ "\tDefenceDiceRoll "+defenceDiceRoll);
					System.out.print("\t Attack: "+attacker2.getAttack() * attackDiceRoll+ "\tDefence: "+  attacker1.getStrength() * defenceDiceRoll);
					if (attack > 0) {
						System.out.println("\tDamage: " + attack);
						attacker1.setHealth(attacker1.getHealth() - attack);
					} else {
						System.out.println("\nAttack defended by "+ attacker2.getName());
					}
					System.out.println("\n\tStats :\n \tAttacker1: " + attacker1.toString() + "\n \tAttacker2: " + attacker2.toString()+"\n");
					Thread.sleep(1000);
				} else {
					System.out.println("Attacker2 is Dead ");
					return attacker1.getName();
				}

				System.out.println("Round Complete Stats :\n Attacker1: " + attacker1.toString() + "\n Attacker2: " + attacker2.toString()+"\n");
                round++;
			}
			return attacker1.getHealth()<0?attacker2.getName():attacker1.getName();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "0";
	}

}
