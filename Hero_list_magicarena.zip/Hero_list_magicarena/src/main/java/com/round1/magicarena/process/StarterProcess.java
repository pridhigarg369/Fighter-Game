package com.round1.magicarena.process;

public interface StarterProcess {
	
	public void processor();

}