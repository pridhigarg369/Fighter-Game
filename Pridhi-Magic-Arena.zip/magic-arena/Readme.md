# Java Magical Arena🔥

Magical Arena is a console-based fighting game developed in Java using Eclipse IDE

# Overview

Game starts with concept of 2 players with 4 specified attributes i.e. String Name, Integer Health, Integer Strength, Integer Attack.
All the 4 attributes are taken as input from the user, 
The Game is Aborted if 
* The user sends a incorrect format for the requested inputs 
* The user sends a out of specified range value for integer attributes more than 3 times.
I have included comments and useful links within the code for help.





# How Game Works: 

* The attacking player rolls an attacking dice.
* The defending player rolls a defending dice.
* The damage created by the attacker is determined by multiplying their "Attack" value by the outcome of the attacking dice roll.
* The defender's "Strength" value is multiplied by the outcome of the defending dice to determine the damage defended.
* Any excess damage created by the attacker, which is not defended by the defender, reduces the defender's health.
* After each round, the stats of both players are displayed.
* The game ends when any player's health drops to 0. 
* The name of the Winning Player is displayed. 



## Set Up

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

2. Extract the zip file to the project directory where you want to keep the project. 
	
3. open Eclipse and follow the steps to import the project:
* File> open projects from file system >
* Import projects from File system or Archive window will appear
* click on directory button and import  the folder in which you extracted the zip file. Check project is selected and hit Finish
* setup the JDK in your eclipse work place if not already configured and Run the Starter.java class .


				
Now you will see magic arena in the project explorer window.

### Prerequisites

For Devlopment : [Eclipse](https://www.eclipse.org/downloads/)
 		
For Running    : [Java JRE](https://www.oracle.com/technetwork/java/javase/downloads/index.html)
 
 
## Built With

*  [Eclipse](https://www.eclipse.org/downloads/)
*  [Java JDK](https://www.oracle.com/technetwork/java/javase/downloads/index.html)
 

