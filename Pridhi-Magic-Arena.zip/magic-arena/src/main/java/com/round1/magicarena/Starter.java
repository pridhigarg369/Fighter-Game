package com.round1.magicarena;

import com.round1.magicarena.processImpl.GameImpl;

/**
 *
 * ${game start up and start the processor}
 */
public class Starter 
{
	
    public static void main( String[] args )
    {   		
    	GameImpl beginGame = new GameImpl();       
        beginGame.start();
    }
}
