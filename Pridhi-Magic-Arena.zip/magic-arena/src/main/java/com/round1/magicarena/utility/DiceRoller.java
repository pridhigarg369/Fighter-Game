package com.round1.magicarena.utility;


public class DiceRoller {

	
	/**
	 *
	 * ${gives a random dice roll value in range 1 to 6}
	 */
	public static int diceRoll() {

		return (int) (Math.random() * 6) + 1;

	}

}
