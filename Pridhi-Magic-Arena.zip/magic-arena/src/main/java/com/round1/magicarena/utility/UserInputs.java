package com.round1.magicarena.utility;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class UserInputs {

	private static Scanner sc = new Scanner(System.in);

	/**
	 *
	 * ${user Input value for player Attribute }
	 */
	public static int getAttribute(int minRange, int maxRange) throws IOException ,InputMismatchException{

		int tries = 1;
		int attribute = 0;
		try {

			attribute = sc.nextInt();
			while (tries != 4) {
				
				if (attribute == 0) {
					System.out.print("\n Invalid Value- You Cannot Start with 0 : Please Enter InRange Value again ");
					attribute = sc.nextInt();
					tries++;
				} else if (attribute < minRange || attribute > maxRange) {
					System.out.println("Invalid Value: Please enter a valid InRange Number again");
					attribute = sc.nextInt();
					tries++;
				} else {
					return attribute;
				}
			}
			System.out.println("\n ******\t Game Aborted after 3 Failed Selection Attempts, Please Restart\t ******");
			abortGame();
		}
		catch(InputMismatchException exception) {
			System.out.println("\n ******\tGame Aborted due to incorrect Input Format, Please Restart ******\t");
			abortGame();
		}
		catch (Exception e) {
			System.out.println("\n ******\tInvalid Value: Please restart the Game ******\t");

			e.printStackTrace();
			abortGame();
		}
		return 0;
	}

	/**
	 *
	 * ${user Input value for player Name }
	 */
	public static String getName() throws IOException {
		try {
			int tries = 1;
			String name="";
			
			while (tries != 3) {
				
				name = sc.nextLine();
				if(!name.isEmpty() && !name.trim().equals("")) {
					return name;
				}
				else {
					tries++;
				}
				
			}
			System.out.println("Game Aborted after 3 Failed entry Attempts, Please Restart");
			abortGame();
			
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		return "0";
	}

	public static void abortGame() {
		System.exit(0);
	}

}
