package com.round1.magicarena.processImpl;


import com.round1.magicarena.entities.Fighter;
import com.round1.magicarena.process.Game;
import com.round1.magicarena.utility.DiceRoller;
import com.round1.magicarena.utility.UserInputs;


/**
*
* ${User Input for player attributes}
* &&
* {Battle initializer}
*/
public class GameImpl implements Game {

	@Override
	public void start() {
		Fighter player1 = new Fighter();
		Fighter player2 = new Fighter();

		System.out.println("\n\n\t***************\t  Heyy There! Players! \t*****************\n");

		try {
			Thread.sleep(1000);
			
			//User Input for Player 1
			System.out.println("\n PLAYER 1 :");
			System.out.print("\n\t Enter Player Name ");
			player1.setName(UserInputs.getName());
			System.out.print("\n\t Enter Health Value in Range 10 to 100");
			player1.setHealth(UserInputs.getAttribute(10, 100));
			System.out.print("\n\t Enter Attack Value  in Range 5 to 25 ");
			player1.setAttack(UserInputs.getAttribute(5, 25));
			System.out.print("\n\t Enter Strength Value  in Range 5 to 25");
			player1.setStrength(UserInputs.getAttribute(5, 25));

			//User Input for Player 2
			System.out.println("\n PLAYER 2 :");
			System.out.print("\n\t Enter Player2 Name ");
			player2.setName(UserInputs.getName());
			System.out.print("\n\t Enter Health Value in Range 10 to 100 ");
			player2.setHealth(UserInputs.getAttribute(10, 100));
			System.out.print("\n\t Enter Attack Value in Range 5 to 25");
			player2.setAttack(UserInputs.getAttribute(5, 25));
			System.out.print("\n\t Enter Strength Value in Range 5 to 25");
			player2.setStrength(UserInputs.getAttribute(5, 25));
			
			
			BattlefieldImpl battle = new BattlefieldImpl();
			String winner = battle.battleBegin(player1, player2);

			System.out.println("\n*****************\t Winner\t: " + winner);

		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			System.out.println("Process Aborted\n Please restart the game and Enter a valid fighter ID");
			e.printStackTrace();
		}
return ;
	}
}
