package com.round1.magicarena.process;


public interface Game {
	
	public void start();

}