package com.Round1.magicarena;

import org.junit.Test;

import com.round1.magicarena.entities.Fighter;
import com.round1.magicarena.utility.DiceRoller;

public class BattleTest {

	// test to check yearly salary
	Fighter player1 = new Fighter("PlayerA", 50, 5, 10);
	Fighter player2 = new Fighter("pLAYERB", 100, 10, 15);

	@Test
	public void attackTest() {

		String winner = "";
		Fighter attacker1;
		Fighter attacker2;
		try {

			if (player1.getHealth() > player2.getHealth()) {
				attacker1 = player2;
				attacker2 = player1;
			} else {
				attacker1 = player1;
				attacker2 = player2;
			}

			while (attacker2.getHealth() > 0 && attacker1.getHealth() > 0) {
				// turn 1
				Fighter attacker = player1;
				Fighter defencer = player2;
				if (attacker1.getHealth() > 0) {

					int attackDiceRoll = 1;
					int defenceDiceRoll = 1;
					int attack = 0;
					try {

						attack = Math.max(0,
								attacker.getAttack() * attackDiceRoll - defencer.getStrength() * defenceDiceRoll);
						defencer.setHealth(defencer.getHealth() - attack);

					} catch (Exception e) {
						e.printStackTrace();
					}

				} else {
					
					winner = defencer.getName();
				}
				// Turn 2

				attacker = player2;
				defencer = player1;
				if (attacker2.getHealth() > 0) {

					int attack = 0;
					try {

						int attackDiceRoll = 1;
						int defenceDiceRoll = 1;

						attack = Math.max(0,
								attacker.getAttack() * attackDiceRoll - defencer.getStrength() * defenceDiceRoll);
						defencer.setHealth(defencer.getHealth() - attack);

					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					
					winner = defencer.getName();
				}
			}
			winner = attacker1.getHealth() <= 0 ? attacker2.getName() : attacker1.getName();
			if (winner.equals("pLAYERB")) {
				System.out.println("****\t Test Passed " + winner);
			} else {
				System.out.println("***** \t Test Failed" + winner);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return;
	}

}
